#!/bin/bash

java -jar bin/dialogc.jar 
